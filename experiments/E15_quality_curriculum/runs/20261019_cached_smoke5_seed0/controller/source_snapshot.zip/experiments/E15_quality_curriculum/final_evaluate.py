"""Exactly one frozen-best dev500 postprocessing pass, after training only."""
import argparse
import json
from pathlib import Path
import signal
import sys
import time
import torch
from .io import HERE, sha, save, sources, snapshot, exclusive
from .train import seed_all, REVISION
from .model import GeometryModel
from .data import load_rows
from .evaluation import quality_monitor


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--run',type=Path,required=True);ap.add_argument('--device',default='cuda')
    ap.add_argument('--resume',action='store_true')
    args=ap.parse_args();folder=args.run.resolve()/'final_evaluation'
    if not folder.is_relative_to(HERE/'runs'):raise ValueError('Not an E15 run')
    with exclusive(folder.with_suffix('.lock')):
        latest=torch.load(args.run/'checkpoints/latest.pt',map_location='cpu',weights_only=False)
        if not latest['finished'] or latest['identity'].get('revision')!=REVISION:
            raise ValueError('Finish the v2 training before final postprocessing')
        if latest['identity']['implementation_check']:raise ValueError('Not a formal model')
        path=args.run/'checkpoints/best.pt';digest=sha(path)
        frozen={'checkpoint_sha256':digest,'identity':latest['identity'],'panel':'dev_monitor500',
                'postprocess':{'normal_seconds':5.,'extra_rescue_seconds':16.}}
        if folder.exists():
            if json.loads((folder/'frozen.json').read_text(encoding='utf-8'))!=frozen:
                raise ValueError('This run already froze a different evaluation; no second candidate allowed')
            if (folder/'results.json').exists():
                print('Final pass already completed; reusing stored result, no inference:',folder,flush=True);return
            if not args.resume:raise ValueError('Use --resume for the same interrupted frozen pass')
        else:
            folder.mkdir(parents=True);save(folder/'frozen.json',frozen)
            save(folder/'config.json',{'command':[sys.executable,*sys.argv],'frozen':frozen})
            snapshot(folder/'source_snapshot.zip',latest['identity'])
        if latest['identity']['sources']!=sources():raise ValueError('Evaluation source changed')
        seed_all(latest['identity']['seed'])
        best=torch.load(path,map_location='cpu',weights_only=False)
        model=GeometryModel(**best['model_config']).to(args.device);model.load_state_dict(best['model'])
        rows=load_rows('dev_monitor500')
        if len(rows)!=500:raise ValueError('The frozen final panel must have 500 cases')
        partial=folder/'partial.json'
        existing=json.loads(partial.read_text(encoding='utf-8')) if partial.exists() else []
        requested=[False];handler=signal.signal(signal.SIGINT,lambda *_:requested.__setitem__(0,True))
        begin=time.perf_counter()
        def stopped():return requested[0] or (folder/'STOP').exists()
        def record(records,stopping):
            save(partial,records)
            save(folder/'progress.json',{'completed':len(records),'total':500,'checkpoint_sha256':digest,
                'elapsed_seconds_this_invocation':time.perf_counter()-begin,'stopped':stopping})
        try:
            result=quality_monitor(model,rows,args.device,should_stop=stopped,existing=existing,on_record=record)
            if result is None:
                print('Paused frozen final evaluation; resume skips completed cases',flush=True);return
            result.update(status='complete',checkpoint_sha256=digest,scope='One frozen best, dev500 after training; not used for selection',
                          test_read=False,tail_test_read=False)
            save(folder/'results.json',result)
            if partial.exists():partial.unlink()
            print(json.dumps(result['summary'],ensure_ascii=False),flush=True)
        finally:signal.signal(signal.SIGINT,handler)


if __name__=='__main__':main()
