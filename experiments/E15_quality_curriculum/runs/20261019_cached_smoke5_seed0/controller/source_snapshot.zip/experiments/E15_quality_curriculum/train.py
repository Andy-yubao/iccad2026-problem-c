"""Cached scratch controls; validation never calls a layout postprocessor."""
import argparse
import copy
import json
import os
from pathlib import Path
import random
import signal
import subprocess
import sys
import time
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
os.environ.setdefault('OMP_NUM_THREADS', '2')
os.environ.setdefault('OPENBLAS_NUM_THREADS', '2')
os.environ.setdefault('MKL_NUM_THREADS', '2')
import numpy as np
import torch
from datasets.quality_layouts import QualityLayouts, REGISTRY
from datasets.paths import resolved_data_paths
from .data import load_rows, collate
from .cache import identity as cache_identity
from .io import ROOT, HERE, sha, save, checkpoint as write_checkpoint, sources, snapshot, exclusive
from .loss import losses, weights
from .model import GeometryModel

ARMS = ('supervised_small', 'curriculum_small', 'curriculum_large')
REVISION = 'E15.cached_no_repair.v2'


def seed_all(seed):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    if torch.cuda.is_available(): torch.cuda.manual_seed_all(seed)
    torch.set_num_threads(2)
    torch.use_deterministic_algorithms(True)


def rng_state():
    return {'python': random.getstate(), 'numpy': np.random.get_state(), 'torch': torch.get_rng_state(),
            'cuda': torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None}


def restore_rng(state):
    random.setstate(state['python']); np.random.set_state(state['numpy']); torch.set_rng_state(state['torch'])
    if state['cuda'] is not None: torch.cuda.set_rng_state_all(state['cuda'])


def selection(values):
    # Fixed across arms and epochs. Do not select checkpoints by the changing
    # curriculum-weighted total, or by a repair that hides poor raw drafts.
    return values['quality_proxy'] + 10*values['overlap'] + .05*values['supervision']


@torch.no_grad()
def monitor_losses(model, rows, device, arm, epoch, batch_size):
    model.eval(); sums = {}
    for start in range(0, len(rows), batch_size):
        selected = [rows[i] for i in range(start, min(start+batch_size, len(rows)))]
        graph, targets = collate(selected, device)
        values = losses(model(graph), graph, targets, arm, epoch, include_quality=True)
        for key, value in values.items(): sums[key] = sums.get(key, 0.) + float(value)*len(selected)
    result = {key: value/len(rows) for key, value in sums.items()}
    result.update(count=len(rows), selection_proxy=selection(result))
    return result


def gradient_norm(value, parameters):
    grads = torch.autograd.grad(value, parameters, retain_graph=True, allow_unused=True)
    return float(sum(g.square().sum() for g in grads if g is not None).sqrt())


def parser():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--arm', choices=ARMS, required=True)
    ap.add_argument('--output', type=Path, required=True)
    ap.add_argument('--device', default='cuda')
    ap.add_argument('--seed', type=int, default=0)
    ap.add_argument('--max-hours', type=float, default=4.)
    ap.add_argument('--max-epochs', type=int, default=200)
    ap.add_argument('--batch-size', type=int, default=16)
    ap.add_argument('--resume', action='store_true')
    return ap


def make_identity(args, implementation_check=False):
    width = 192 if args.arm == 'curriculum_large' else 96
    return {'revision': REVISION, 'arm': args.arm, 'initialization': 'random; preserved on explicit continuation',
        'width': width, 'layers': 4, 'parameters': 1970323 if width == 192 else 497299,
        'sources': sources(), 'registry_sha256': sha(REGISTRY), 'paths_sha256': sha(ROOT/'protocol/paths.json'),
        'cache_identity': cache_identity(), 'seed': args.seed, 'device': args.device,
        'torch': str(torch.__version__), 'numpy': np.__version__, 'cuda': torch.version.cuda,
        'device_name': torch.cuda.get_device_name(args.device) if args.device.startswith('cuda') else 'cpu',
        'max_seconds': args.max_hours*3600, 'max_epochs': args.max_epochs, 'batch_size': args.batch_size,
        'lr': 1e-4, 'weight_decay': 1e-4, 'clip_norm': 1., 'monitor_interval_epochs': 1,
        'schedule': 'epochs1..5 sup1 quality.05 overlap10; linear epochs6..20 to sup.05 quality1 overlap10; supervised sup1 only',
        'selection': 'dev500: quality_proxy + 10*overlap + .05*supervision; fixed across arms/epochs',
        'lr_patience_checks': 4, 'early_patience_checks': 12, 'scheduler_start_epoch': 20,
        'training_postprocessing': False, 'validation_postprocessing': False,
        'implementation_check': implementation_check, 'test_read': False, 'tail_test_read': False}


def fresh_progress(count):
    return {'epoch': 0, 'cursor': 0, 'order': None, 'step': 0, 'seen': np.zeros(count, dtype=bool),
        'best_proxy': None, 'best_epoch': None, 'bad_checks': 0, 'pending_monitor': False,
        'history': [], 'gradient_history': [], 'batch_history': [], 'full_dev_complete': False}


def run(args, **kwargs):
    with exclusive(Path(args.output).with_suffix('.lock')):
        return _run(args, **kwargs)


def _run(args, *, implementation_check=False, stop_after_steps=None, check_rows=None):
    begin = time.perf_counter(); args.output = args.output.resolve()
    if not args.output.is_relative_to(HERE/'runs'): raise ValueError('Output must stay in E15/runs')
    if min(args.max_hours, args.max_epochs, args.batch_size) <= 0: raise ValueError('Positive budgets required')
    if args.device.startswith('cuda') and not torch.cuda.is_available(): raise RuntimeError('CUDA unavailable')
    seed_all(args.seed)
    identity = make_identity(args, implementation_check)
    model = GeometryModel(identity['width'], 4).to(args.device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=1e-4, weight_decay=1e-4)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, factor=.5, patience=3,
                        threshold=1e-5, threshold_mode='abs', min_lr=1e-6)
    previous = None; prior = 0.
    if args.resume:
        previous = torch.load(args.output/'checkpoints/latest.pt', map_location='cpu', weights_only=False)
        if previous['identity'] != identity: raise ValueError('Resume source/data/budget/device identity mismatch')
        if previous['finished']:
            print('Already finished:', previous['status'], flush=True); return
        if (args.output/'STOP').exists(): raise ValueError('Remove STOP before resuming')
        model.load_state_dict(previous['model']); optimizer.load_state_dict(previous['optimizer'])
        scheduler.load_state_dict(previous['scheduler']); prior = previous['elapsed_seconds']
        if (args.output/'budget.json').exists():
            prior = max(prior, json.loads((args.output/'budget.json').read_text(encoding='utf-8'))['elapsed_seconds'])
    else:
        args.output.mkdir(parents=True, exist_ok=False)
        save(args.output/'config.json', {'identity': identity, 'command': [sys.executable, *sys.argv],
            'commit': subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
            'git_status': subprocess.check_output(['git','status','--short'],cwd=ROOT,text=True).strip(),
            'data_paths': resolved_data_paths(), 'shared_cache_preparation': 'Separate one-time stage; no model updates',
            'timing': 'Cumulative training-stage wall includes mmap load/validation; inherited old wall is not reset'})
        snapshot(args.output/'source_snapshot.zip', identity)
    elapsed = lambda: prior+time.perf_counter()-begin
    calls_path = args.output/'invocations.json'
    calls = json.loads(calls_path.read_text(encoding='utf-8')) if calls_path.exists() else []
    calls.append({'argv': [sys.executable,*sys.argv], 'resume': args.resume, 'prior_seconds': prior,
                  'started_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())})
    save(calls_path,calls)
    train_meta, dev_meta = QualityLayouts('train'), QualityLayouts('dev')
    mon_meta = QualityLayouts('train_monitor500')
    member_map = {tuple(r['member']):i for i,r in enumerate(train_meta.records)}
    if {m[0] for m in member_map} & {r['member'][0] for r in dev_meta.records}:
        raise ValueError('Student source shards overlap')
    if implementation_check:
        if check_rows is None: raise ValueError('Supply the five preloaded check rows')
        train, dev = check_rows; monitor_ids = list(range(len(train)))
    else:
        train = load_rows('train'); dev = load_rows('dev_monitor500')
        monitor_ids = [member_map[tuple(r['member'])] for r in mon_meta.records]
    train_monitor = [train[i] for i in monitor_ids]
    progress = previous['progress'] if previous and previous['progress'] is not None else fresh_progress(len(train))
    if previous: restore_rng(previous['rng'])
    requested = [False]
    old_handler = signal.signal(signal.SIGINT, lambda *_: requested.__setitem__(0,True))
    def stopped():
        return requested[0] or (args.output/'STOP').exists() or (stop_after_steps is not None and progress['step']>=stop_after_steps)
    def exhausted(): return elapsed()>=identity['max_seconds']
    def heartbeat(): save(args.output/'budget.json', {'elapsed_seconds':elapsed()})
    def store(status, finished=False, best=False):
        heartbeat()
        state = {'model':model.state_dict(), 'model_config':{'width':identity['width'],'layers':4},
            'optimizer':optimizer.state_dict(), 'scheduler':scheduler.state_dict(), 'rng':rng_state(),
            'progress':progress, 'identity':identity, 'elapsed_seconds':elapsed(), 'status':status, 'finished':finished}
        write_checkpoint(args.output/'checkpoints/latest.pt',state)
        if best: write_checkpoint(args.output/'checkpoints/best.pt',state)
        save(args.output/'progress.json', {'status':status,'finished':finished,'epoch':progress['epoch'],
            'cursor':progress['cursor'],'step':progress['step'],'seen_count':int(progress['seen'].sum()),
            'elapsed_seconds':elapsed(),'best_proxy':progress['best_proxy'],'best_epoch':progress['best_epoch'],
            'bad_checks':progress['bad_checks'],'history':progress['history'],'gradients':progress['gradient_history'],
            'full_dev_complete':progress['full_dev_complete'],'postprocessing_calls':0,
            'implementation_check':implementation_check,'test_read':False,'tail_test_read':False})
    def monitor():
        if stopped() or exhausted(): return False
        epoch = progress['epoch']
        val = monitor_losses(model,dev,args.device,args.arm,max(1,epoch),args.batch_size)
        tr = monitor_losses(model,train_monitor,args.device,args.arm,max(1,epoch),args.batch_size)
        seen = progress['seen'][monitor_ids]
        record = {'epoch':epoch,'step':progress['step'],'dev_monitor':val,'train_monitor':tr,
            'train_seen_count':int(seen.sum()),'weights':weights(args.arm,max(1,epoch)),
            'lr':optimizer.param_groups[0]['lr'],'elapsed_seconds':elapsed(),'postprocessing_calls':0}
        for label,mask in (('train_seen',seen),('train_unseen',~seen)):
            if mask.any():
                record[label] = tr if mask.all() else monitor_losses(model,
                    [row for row,flag in zip(train_monitor,mask) if flag],args.device,args.arm,max(1,epoch),args.batch_size)
        improved = progress['best_proxy'] is None or val['selection_proxy']<progress['best_proxy']-1e-5
        if improved: progress['best_proxy'],progress['best_epoch'],progress['bad_checks'] = val['selection_proxy'],epoch,0
        elif epoch>=20: progress['bad_checks']+=1
        if epoch>=20: scheduler.step(val['selection_proxy'])
        progress['history'].append(record);progress['pending_monitor']=False
        store('running',best=improved)
        print(f'epoch={epoch} step={progress["step"]} dev_proxy={val["selection_proxy"]:.6f} supervision={val["supervision"]:.6f} lr={optimizer.param_groups[0]["lr"]:.2g} (no postprocessing)',flush=True)
        return True
    status = 'running'
    try:
        save(args.output/'panels.json', {'train_count':len(train),'dev_monitor_count':len(dev),
            'train_monitor_members':[list(r['member']) for r in train_monitor],
            'dev_monitor_members':[list(dev[i]['member']) for i in range(len(dev))],
            'test_read':False,'tail_test_read':False,'postprocessing_calls':0})
        if not previous: store('prepared'); monitor()
        while progress['epoch']<args.max_epochs or progress['pending_monitor']:
            if stopped() or exhausted(): status='user_stop' if stopped() else 'budget';break
            if progress['pending_monitor']:
                if not monitor(): status='user_stop' if stopped() else 'budget';break
                if progress['bad_checks']>=12: status='early_stop';break
                continue
            if progress['order'] is None:
                progress['order']=np.random.default_rng(args.seed+progress['epoch']).permutation(len(train));progress['cursor']=0
            model.train()
            while progress['cursor']<len(train):
                if stopped() or exhausted():break
                ids=progress['order'][progress['cursor']:progress['cursor']+args.batch_size]
                graph,targets=collate([train[i] for i in ids],args.device)
                optimizer.zero_grad(set_to_none=True)
                values=losses(model(graph),graph,targets,args.arm,progress['epoch']+1,
                              include_quality=args.arm!='supervised_small')
                if not all(torch.isfinite(v) for v in values.values()):raise RuntimeError('Nonfinite loss')
                if progress['cursor']==0:
                    params=list(model.parameters());diag={'epoch':progress['epoch']+1,'weights':weights(args.arm,progress['epoch']+1)}
                    for key in ('supervision','quality_proxy','overlap'):
                        if key in values:diag[key+'_grad_norm']=gradient_norm(values[key],params)
                    progress['gradient_history'].append(diag)
                values['total'].backward()
                norm=float(torch.nn.utils.clip_grad_norm_(model.parameters(),1.,error_if_nonfinite=True))
                optimizer.step();progress['seen'][ids]=True;progress['cursor']+=len(ids);progress['step']+=1
                heartbeat()
                if progress['step']%100==0:
                    progress['batch_history'].append({'step':progress['step'],'epoch':progress['epoch']+1,
                        'losses':{k:float(v.detach()) for k,v in values.items()},'grad_norm':norm,'elapsed_seconds':elapsed()})
                    store('running');print(f'step={progress["step"]} epoch={progress["epoch"]+1} samples={progress["cursor"]}/{len(train)} total={float(values["total"].detach()):.5f}',flush=True)
            if progress['cursor']<len(train):status='user_stop' if stopped() else 'budget';break
            progress['epoch']+=1;progress['order']=None;progress['cursor']=0;progress['pending_monitor']=True
            store('monitor_pending')
        if status=='running':status='max_epochs'
        if status in ('max_epochs','early_stop') and not implementation_check and not exhausted() and not stopped():
            best_path=args.output/'checkpoints/best.pt'
            if best_path.exists():
                current=copy.deepcopy(model.state_dict())
                best=torch.load(best_path,map_location='cpu',weights_only=False)
                try:
                    model.load_state_dict(best['model'])
                    full=load_rows('dev')
                    values=monitor_losses(model,full,args.device,args.arm,max(1,best['progress']['epoch']),args.batch_size)
                    save(args.output/'full_dev.json',{'count':len(full),'checkpoint_sha256':sha(best_path),
                        'losses':values,'postprocessing_calls':0,'test_read':False})
                    progress['full_dev_complete']=True
                finally:model.load_state_dict(current)
        store(status,finished=status in ('budget','max_epochs','early_stop'))
        save(args.output/'results.json',{'status':status,'elapsed_seconds':elapsed(),'steps':progress['step'],
            'epochs':progress['epoch'],'best_epoch':progress['best_epoch'],'best_proxy':progress['best_proxy'],
            'full_dev_complete':progress['full_dev_complete'],'postprocessing_calls':0,
            'test_read':False,'tail_test_read':False,'implementation_check':implementation_check,
            'final_postprocessed_Q':'not run; one frozen best assessment is a separate stage'})
        print('Stopped:',status,'wall hours:',elapsed()/3600,'best epoch:',progress['best_epoch'],flush=True)
    except BaseException:
        store('error');raise
    finally:signal.signal(signal.SIGINT,old_handler)


if __name__=='__main__':run(parser().parse_args())
