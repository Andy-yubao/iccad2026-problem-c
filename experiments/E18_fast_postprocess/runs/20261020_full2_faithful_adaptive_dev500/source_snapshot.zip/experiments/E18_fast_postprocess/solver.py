"""Budgeted vectorized geometry controls, immutable model and legal incumbent."""
import time
import numpy as np
import math
from .backend.frozen.packing import prepare_problem,_dimensions
from .backend.frozen.feasible import Objective,row_control
from .backend.frozen.solver import hard_valid
from .backend.guard import repair_tiny_negative
from .fast_geometry import topology,step,contact_tree,reduce_edges
from .canonical import canonicalize
from .projection import solve as project


def raw_measures(x,p):
    center=x[:,:2]+x[:,2:]/2;wire=0.
    if len(p.b2b):
        i,j=p.b2b[:,:2].astype(int).T;wire+=float((np.abs(center[i]-center[j]).sum(1)*p.b2b[:,2]).sum())
    if len(p.p2b):
        i,j=p.p2b[:,:2].astype(int).T;wire+=float((np.abs(p.pins[i]-center[j]).sum(1)*p.p2b[:,2]).sum())
    area=float(np.prod((x[:,:2]+x[:,2:]).max(0)-x[:,:2].min(0)))
    return area,wire


def optimize(draft,inputs,*,iterations=4,mode=0,projection=True,seconds=.21,
             boundary=12.,contact=6.,reweighted=True,relaxed=False,hard=False,reserve=0.,snap=1e-6,
             group_order=False,elastic_strength=100000.,adaptive=False,draft_proxy=False,rescue=False,
             repair_edges=False,hybrid=False,near_seed=False,seed_order=0,safe_mode=False,plateau=False):
    start=time.perf_counter();p=prepare_problem(*inputs);obj=Objective(p)
    if adaptive:
        iterations,seconds,reserve=(24,.09,.025) if p.n<60 else ((24,.17,.045) if p.n<90 else ((24,.34,.065) if p.n<110 else (24,.55,.08)))
    anchors=None
    if draft_proxy:
        anchor_area,anchor_wire=raw_measures(draft,p)
        anchors=(max(anchor_area/p.scale**2,1e-8),max(anchor_wire/p.scale,1e-8))
        objective=obj
        def normalized(x):
            a,w=raw_measures(x,p)
            return math.log(1+.5*max(0,a/anchor_area-1)+.5*max(0,w/max(anchor_wire,1e-8)-1))+2*sum(objective.violations(x))/objective.nsoft
        obj=normalized
    best=row_control(p);value=obj(best);trace=[];overrides={};infeasible=False;legal_steps=0
    widths,heights=_dimensions(p,draft[:,2]/draft[:,3],True)
    state=np.column_stack((draft[:,:2],widths,heights))
    if near_seed:
        from .legal_seed import seed
        state=seed(p,draft,seed_order)
    def accept(x,label):
        nonlocal best,value
        if x is None:return False
        x=canonicalize(x,p,tolerance=snap);x,_=repair_tiny_negative(x,p)
        if not hard_valid(x,p):return False
        score=obj(x)
        if score<value:
            best=x.copy();value=score
        return x
    accept(draft,'raw')
    if near_seed:accept(state,'near_seed')
    def relations(state):
        full=topology(state,p.constraints,mode=mode,array=True,group_order=group_order)
        if safe_mode:
            a,b,c=full.T
            invalid=state[b,c]-state[a,c]-state[a,c+2]<-1e-7
            physical=topology(state,p.constraints,mode=0,array=True)
            full[invalid]=physical[invalid]
        for (i,j),edge in overrides.items():full[max(i,j)*(max(i,j)-1)//2+min(i,j)]=edge
        return full
    stale=0
    for iteration in range(iterations):
        left=seconds-(time.perf_counter()-start)
        if left<.015+reserve:break
        full=relations(state);edges=reduce_edges(full,p.n)
        proposal,stats=step(p,state,edges,seconds=max(.01,left-reserve),boundary=boundary,contact=contact,
            reweighted=reweighted,conservative=(not relaxed or (hybrid and legal_steps>=2)),full_edges=full,elastic=0. if hard else elastic_strength*(1+iteration/3),anchors=anchors)
        previous_value=value;clean=accept(proposal,'shape')
        trace.append({'phase':'shape','legal':isinstance(clean,np.ndarray),**stats})
        if proposal is None:
            infeasible=stats['status']=='PrimalInfeasible'
            if repair_edges and stats.get('conflicting_edges'):
                candidates=stats['conflicting_edges'];changed=0
                for a,b,axis,weight in candidates:
                    key=(min(a,b),max(a,b))
                    if key in overrides:continue
                    other=1-axis;centers=state[:,:2]+state[:,2:]/2
                    first,second=(a,b) if centers[a,other]<=centers[b,other] else (b,a)
                    overrides[key]=(first,second,other);changed+=1
                    trace.append({'phase':'conflict_repair','old':[a,b,axis],'new':[first,second,other],'dual_weight':weight})
                    if changed==2:break
                if changed:continue
            break
        infeasible=False
        legal_steps+=int(isinstance(clean,np.ndarray))
        state=clean if isinstance(clean,np.ndarray) else proposal
        if plateau and isinstance(clean,np.ndarray):
            stale=stale+1 if previous_value-value<1e-5 else 0
            if stale>=2 and legal_steps>=4 and sum(Objective(p).violations(best))==0:break
    if projection and not infeasible and seconds-(time.perf_counter()-start)>.015:
        full=relations(state);tree=contact_tree(state,p,full)
        proposed,stats=project(p,state,reduce_edges(full,p.n),tree,contact=contact,boundary=boundary,
            seconds=max(.01,seconds-(time.perf_counter()-start)),anchors=anchors)
        legal=accept(proposed,'project');trace.append({'phase':'project','legal':isinstance(legal,np.ndarray),**stats})
    if rescue and np.array_equal(best,row_control(p)):
        alternate,alternate_stats=optimize(draft,inputs,iterations=6,mode=1-mode,projection=True,
            seconds=.23,hard=True,relaxed=True,reserve=.05,snap=snap,repair_edges=True)
        accept(alternate,'alternate_relations');trace.append({'phase':'alternate_relations','seconds':alternate_stats['seconds']})
    if rescue and np.array_equal(best,row_control(p)):
        from .backend.rescue import seed_pack
        for seed_mode in [2,0]:
            packed=seed_pack(draft,inputs,seed_mode,seconds=.08)
            if packed is None:continue
            accept(packed,'packed_rescue')
            refined,substats=optimize(packed,inputs,iterations=4,mode=1,projection=True,
                seconds=.14,hard=True,relaxed=True,reserve=.04,snap=snap,repair_edges=True)
            accept(refined,'packed_polish');trace.append({'phase':'packed_rescue','mode':seed_mode,'seconds':substats['seconds']})
            if obj(best)<.5:break
    assert hard_valid(best,p)
    return best,{'seconds':time.perf_counter()-start,'proxy':value,'trace':trace,
        'row_retained':bool(np.array_equal(best,row_control(p)))}
