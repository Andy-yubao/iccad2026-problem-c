"""Budgeted vectorized geometry controls, immutable model and legal incumbent."""
import time
import numpy as np
from .backend.frozen.packing import prepare_problem,_dimensions
from .backend.frozen.feasible import Objective,row_control
from .backend.frozen.solver import hard_valid
from .backend.guard import repair_tiny_negative
from .fast_geometry import topology,step,contact_tree,reduce_edges
from .canonical import canonicalize
from .projection import solve as project


def optimize(draft,inputs,*,iterations=4,mode=0,projection=True,seconds=.21,
             boundary=12.,contact=6.,reweighted=True,relaxed=False,hard=False,reserve=0.,snap=1e-6,
             group_order=False,elastic_strength=100000.):
    start=time.perf_counter();p=prepare_problem(*inputs);obj=Objective(p)
    best=row_control(p);value=obj(best);trace=[]
    widths,heights=_dimensions(p,draft[:,2]/draft[:,3],True)
    state=np.column_stack((draft[:,:2],widths,heights))
    def accept(x,label):
        nonlocal best,value
        if x is None:return False
        x=canonicalize(x,p,tolerance=snap);x,_=repair_tiny_negative(x,p)
        if not hard_valid(x,p):return False
        score=obj(x)
        if score<value:
            best=x.copy();value=score
        return x
    accept(draft,'raw')
    for iteration in range(iterations):
        left=seconds-(time.perf_counter()-start)
        if left<.015+reserve:break
        full=topology(state,p.constraints,mode=mode,array=True,group_order=group_order);edges=reduce_edges(full,p.n)
        proposal,stats=step(p,state,edges,seconds=max(.01,left-reserve),boundary=boundary,contact=contact,
            reweighted=reweighted,conservative=not relaxed,full_edges=full,elastic=0. if hard else elastic_strength*(1+iteration/3))
        clean=accept(proposal,'shape')
        trace.append({'phase':'shape','legal':isinstance(clean,np.ndarray),**stats})
        if proposal is None:break
        state=clean if isinstance(clean,np.ndarray) else proposal
    if projection and seconds-(time.perf_counter()-start)>.015:
        full=topology(state,p.constraints,mode=mode,array=True,group_order=group_order);tree=contact_tree(state,p,full)
        proposed,stats=project(p,state,reduce_edges(full,p.n),tree,contact=contact,boundary=boundary,
            seconds=max(.01,seconds-(time.perf_counter()-start)))
        legal=accept(proposed,'project');trace.append({'phase':'project','legal':isinstance(legal,np.ndarray),**stats})
    assert hard_valid(best,p)
    return best,{'seconds':time.perf_counter()-start,'proxy':value,'trace':trace,
        'row_retained':bool(np.array_equal(best,row_control(p)))}
