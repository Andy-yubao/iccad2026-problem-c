"""Reference-free subprocess boundary; only public solver inputs are accepted."""
import argparse
import json
from pathlib import Path
import time
import numpy as np


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('request',type=Path)
    parser.add_argument('response',type=Path)
    args=parser.parse_args()
    payload=json.loads(args.request.read_text(encoding='utf-8'))
    if set(payload) != {'inputs','draft','variant','seconds'}:
        raise ValueError('Only public inputs allowed across worker boundary')
    inputs=(int(payload['inputs'][0]),*[np.asarray(x) for x in payload['inputs'][1:]])
    raw=np.asarray(payload['draft'],dtype=float)
    from .frozen.solver import optimize as control
    from .observe import Observe
    from .fast_solver import optimize as fast
    from .shape_first import optimize as shape_first
    start=time.perf_counter()
    try:
        if payload['variant'] in ('control120','control_short'):
            with Observe() as observation:
                final,stats=control(raw,inputs,seconds=payload['seconds'],shape_steps=24,
                                    reweighted=True,mip_seconds=0.)
            observed=observation.result()
            stats['observation']=observed
            stats['improvements']=observed.pop('improvements')
        elif payload['variant'].startswith(('shape_first','linear_area')):
            final,stats=shape_first(raw,inputs,seconds=payload['seconds'],linear_area=payload['variant'].startswith('linear_area'))
        else:
            final,stats=fast(raw,inputs,seconds=payload['seconds'],reduced=payload['variant']=='sparse_short')
        result={'positions':final.tolist(),'stats':stats,'solve_seconds':time.perf_counter()-start}
    except Exception as exc:
        result={'error':{'type':type(exc).__name__,'message':str(exc)},
                'solve_seconds':time.perf_counter()-start}
    args.response.write_text(json.dumps(result,ensure_ascii=False,allow_nan=False),encoding='utf-8')


if __name__=='__main__':
    main()
