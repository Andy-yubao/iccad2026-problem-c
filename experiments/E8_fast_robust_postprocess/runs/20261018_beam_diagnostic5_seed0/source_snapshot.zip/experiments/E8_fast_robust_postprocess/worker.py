"""Reference-free subprocess boundary; only public solver inputs are accepted."""
import argparse
import json
import signal
from pathlib import Path
import time
import numpy as np


def main():
    signal.signal(signal.SIGINT,signal.SIG_IGN)
    parser=argparse.ArgumentParser()
    parser.add_argument('request',type=Path)
    parser.add_argument('response',type=Path)
    args=parser.parse_args()
    payload=json.loads(args.request.read_text(encoding='utf-8'))
    if set(payload) != {'inputs','draft','variant','seconds'}:
        raise ValueError('Only public inputs allowed across worker boundary')
    inputs=(int(payload['inputs'][0]),*[np.asarray(x) for x in payload['inputs'][1:]])
    raw=np.asarray(payload['draft'],dtype=float)
    from .frozen.solver import optimize as control
    from .observe import Observe
    from .fast_solver import optimize as fast
    from .shape_first import optimize as shape_first
    from .certificate import infeasibility_certificate
    from .topology_repair import optimize as topology_repair
    from .frozen import global_refine,solver
    from .guard import guarded_refine
    from .beam_topology import optimize as beam_topology
    start=time.perf_counter()
    try:
        if payload['variant'] in ('control120','control_short','certified120','certified_short','safe120'):
            with Observe() as observation:
                if payload['variant']=='safe120':
                    observation.patch(solver,'refine',guarded_refine(solver.refine))
                if payload['variant'].startswith('certified'):
                    original=global_refine.solve_lp
                    def screened(problem,seed,edges,**kwargs):
                        certificate=infeasibility_certificate(problem,seed,edges)
                        if certificate is not None:
                            return None,{'status':'certified_infeasible_without_LP','certificate':certificate}
                        return original(problem,seed,edges,**kwargs)
                    observation.patch(global_refine,'solve_lp',screened)
                final,stats=control(raw,inputs,seconds=payload['seconds'],shape_steps=24,
                                    reweighted=True,mip_seconds=0.)
            observed=observation.result()
            stats['observation']=observed
            stats['improvements']=observed.pop('improvements')
        elif payload['variant'].startswith('beam_'):
            final,stats=beam_topology(raw,inputs,seconds=payload['seconds'])
        elif payload['variant'].startswith('topology_'):
            final,stats=topology_repair(raw,inputs,seconds=payload['seconds'])
        elif payload['variant'].startswith(('shape_first','linear_area')):
            final,stats=shape_first(raw,inputs,seconds=payload['seconds'],linear_area=payload['variant'].startswith('linear_area'))
        else:
            final,stats=fast(raw,inputs,seconds=payload['seconds'],reduced=payload['variant']=='sparse_short')
        result={'positions':final.tolist(),'stats':stats,'solve_seconds':time.perf_counter()-start}
    except Exception as exc:
        result={'error':{'type':type(exc).__name__,'message':str(exc)},
                'solve_seconds':time.perf_counter()-start}
    args.response.write_text(json.dumps(result,ensure_ascii=False,allow_nan=False),encoding='utf-8')


if __name__=='__main__':
    main()
