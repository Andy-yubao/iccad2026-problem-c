"""Selected E8 postprocessor. Inputs are the public problem tuple and E7 draft.

Call optimize(draft_xywh, masked_solver_inputs) -> (hard_legal_xywh, stats).
1.3 seconds is a target budget; actual overhead and maximum time are reported.
The default recipe is exactly the conic_diagonal dev100 configuration.
"""
from .conic_geometry import optimize as _optimize


def optimize(draft,solver_inputs,seconds=1.3):
    return _optimize(draft,solver_inputs,seconds=seconds,conservative=True,
                     reduced=True,quadratic_wire=True,diagonal_wire=True)
