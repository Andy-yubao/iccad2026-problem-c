"""Research adapters and optimizers; archived official sources stay unchanged."""
