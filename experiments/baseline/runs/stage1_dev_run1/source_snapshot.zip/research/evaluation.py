"""Frozen five-case data adapter and independent research scoring.

Only this evaluator owns reference layouts and metrics.  The optimizer receives
ordinary inputs plus the official masked fixed/preplaced XYWH specification.
No local-test payload is opened by this module.
"""
from dataclasses import asdict, dataclass
import importlib
import math
import os
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parents[1]
PUBLIC_CASE_IDS = [0, 19, 39, 69, 99]


def official_evaluator():
    os.environ.setdefault("MPLBACKEND", "Agg")
    os.environ.setdefault("MPLCONFIGDIR", str(ROOT / ".cache/matplotlib"))
    contest = str(ROOT / "third_party/FloorSet/iccad2026contest")
    if contest not in sys.path:
        sys.path.insert(0, contest)
    official = importlib.import_module("iccad2026_evaluate")
    if not official.SHAPELY_AVAILABLE:
        raise RuntimeError("Shapely is required; otherwise grouping violations would be silently omitted")
    return official


@dataclass
class ResearchCase:
    case_id: str
    source: dict
    solver_inputs: tuple
    reference_positions: list
    baseline_metrics: dict

    @property
    def block_count(self):
        return self.solver_inputs[0]

    def input_summary(self):
        constraints = self.solver_inputs[5]
        return {
            "block_count": self.block_count,
            "fixed_blocks": int((constraints[:, 0] != 0).sum()),
            "preplaced_blocks": int((constraints[:, 1] != 0).sum()),
            "boundary_blocks": int((constraints[:, 4] != 0).sum()),
            "grouped_blocks": int((constraints[:, 3] != 0).sum()),
            "mib_blocks": int((constraints[:, 2] != 0).sum()),
        }


def allowed_target_positions(reference_positions, constraints):
    """Expose XYWH for preplaced, WH for fixed, and nothing for free blocks."""
    import torch
    n = len(reference_positions)
    allowed = torch.full((n, 4), -1.0, dtype=torch.float32)
    for i in range(n):
        if bool(constraints[i, 1]):
            allowed[i] = torch.tensor(reference_positions[i], dtype=allowed.dtype)
        elif bool(constraints[i, 0]):
            allowed[i, 2:] = torch.tensor(reference_positions[i][2:], dtype=allowed.dtype)
    return allowed


def _build_case(case_id, source, ordinary_inputs, reference, metrics):
    areas, b2b, p2b, pins, constraints = [value.detach().cpu().clone() for value in ordinary_inputs]
    n = int((areas != -1).sum())
    if n != len(areas) or len(reference) != n:
        raise ValueError(f"{case_id}: expected unpadded inputs and exactly {n} reference rectangles")
    if constraints.ndim != 2 or constraints.shape[1] < 5:
        raise ValueError(f"{case_id}: unsupported constraint schema {tuple(constraints.shape)}")
    reference = [[float(v) for v in row] for row in reference]
    if any(len(row) != 4 or not all(math.isfinite(v) for v in row) or min(row[2:]) <= 0
           for row in reference):
        raise ValueError(f"{case_id}: malformed reference geometry")
    official = official_evaluator()
    baseline = {
        "hpwl_baseline": official.calculate_hpwl_b2b(reference, b2b)
                         + official.calculate_hpwl_p2b(reference, p2b, pins),
        "area_baseline": official.calculate_bbox_area(reference),
    }
    # Match ContestEvaluator._extract_baseline's preference for stored metrics.
    if metrics is not None and len(metrics) >= 8:
        b2b_wl = official.calculate_hpwl_b2b(reference, b2b)
        p2b_wl = official.calculate_hpwl_p2b(reference, p2b, pins)
        if float(metrics[0]) > 0:
            baseline["area_baseline"] = float(metrics[0])
        if float(metrics[-2]) > 0:
            b2b_wl = float(metrics[-2])
        if float(metrics[-1]) >= 0:
            p2b_wl = float(metrics[-1])
        baseline["hpwl_baseline"] = b2b_wl + p2b_wl
    specs = allowed_target_positions(reference, constraints)
    return ResearchCase(case_id, source, (n, areas, b2b, p2b, pins, constraints, specs),
                        reference, baseline)


def load_frozen_cases(panel="dev", root=ROOT):
    """Read only the five frozen dev samples or five public compatibility cases.

    Training fp_sol uses WHXY; public labels are polygons.  Loading follows the
    official raw file schemas directly and never calls its auto-downloader.
    """
    import json
    import torch
    root = Path(root).resolve()
    split = json.loads((root / "protocol/split_v1.json").read_text(encoding="utf-8"))
    cases = []
    if panel == "dev":
        selected = split["dev_smoke_panel"]
        if len(selected) != 5 or any(entry["shard"] not in split["shards"]["dev"] for entry in selected):
            raise ValueError("Frozen dev panel must contain exactly five development samples")
        data_root = (root / split["data_root_relative_to_workspace"]).resolve()
        for entry in selected:
            path = (data_root / entry["shard"]).resolve()
            if not path.is_relative_to(data_root):
                raise ValueError("Invalid dev shard path")
            raw = torch.load(path, map_location="cpu", weights_only=False)
            idx = int(entry["sample_index"])
            block_features = raw[0][idx]
            ordinary = (block_features[:, 0], raw[1][idx], raw[2][idx], raw[3][idx], block_features[:, 1:])
            # Official training schema: width, height, x, y -> x, y, width, height.
            reference = raw[5][idx][:, [2, 3, 0, 1]].tolist()
            source = {"split": "dev", "shard": entry["shard"], "sample_index": idx,
                      "paths": [path.relative_to(root).as_posix()]}
            cases.append(_build_case(f"dev:{entry['shard']}:{idx}", source, ordinary, reference, raw[6][idx]))
    elif panel == "public":
        if split["public_compatibility_case_ids"] != PUBLIC_CASE_IDS:
            raise ValueError("Unexpected public compatibility panel; protocol review required")
        for idx in PUBLIC_CASE_IDS:
            folder = root / f"third_party/FloorSet/LiteTensorDataTest/config_{21 + idx}"
            input_path, label_path = folder / "litedata_1.pth", folder / "litelabel_1.pth"
            raw_input = torch.load(input_path, map_location="cpu", weights_only=False)[0]
            metrics, polygons = torch.load(label_path, map_location="cpu", weights_only=False)[0]
            ordinary = (raw_input[0][:, 0], raw_input[1], raw_input[2], raw_input[3], raw_input[0][:, 1:])
            reference = []
            for polygon in polygons:
                valid = polygon[polygon[:, 0] != -1]
                lower, upper = valid.min(dim=0).values, valid.max(dim=0).values
                reference.append([*lower.tolist(), *(upper - lower).tolist()])
            source = {"split": "public_compatibility", "public_case_id": idx,
                      "paths": [p.relative_to(root).as_posix() for p in (input_path, label_path)]}
            cases.append(_build_case(f"public:{idx}", source, ordinary, reference, metrics))
    else:
        raise ValueError("Only dev and public panels are available; local_test is sealed")
    return cases


def evaluate_case(case, positions, runtime_seconds):
    """Use official scoring with runtime factor 1 and an independent hard check."""
    from scripts.audit_baseline_five import independent_hard_checks
    if hasattr(positions, "tolist"):
        positions = positions.tolist()
    positions = [[float(v) for v in row] for row in positions]
    if len(positions) != case.block_count or any(len(row) != 4 for row in positions):
        raise ValueError("Optimizer must return exactly block_count rows of XYWH")
    if any(not all(math.isfinite(v) for v in row) or min(row[2:]) <= 0 for row in positions):
        raise ValueError("Optimizer returned non-finite coordinates or nonpositive dimensions")
    n, areas, b2b, p2b, pins, constraints, _ = case.solver_inputs
    independent = independent_hard_checks(positions, areas, constraints, case.reference_positions)
    official = official_evaluator()
    # Scoring runtime=median_runtime=1 avoids the official 0.01s denominator floor.
    # Actual measured runtime is restored in the output field below.
    metrics = asdict(official.evaluate_solution(
        {"positions": positions, "runtime": 1.0}, case.baseline_metrics,
        constraints, b2b, p2b, pins, areas, case.reference_positions, median_runtime=1.0))
    metrics["runtime_seconds"] = float(runtime_seconds)
    if metrics["is_feasible"] != independent["is_feasible"]:
        raise AssertionError("Official and independent feasibility check disagree")
    if metrics["dimension_violations"] != independent["dimension_or_location_violation_count"]:
        raise AssertionError("Official and independent fixed/preplaced checks disagree")
    # Q&A requires nonnegative coordinates, but the archived evaluator and audit
    # omit this check.  Preserve its raw flag and explicitly enforce the input
    # contract in the research feasibility/cost rather than accepting a loophole.
    negative = [i for i, row in enumerate(positions) if row[0] < 0 or row[1] < 0]
    metrics["official_is_feasible_before_nonnegative_check"] = metrics["is_feasible"]
    metrics["nonnegative_coordinate_violations"] = len(negative)
    independent["negative_coordinate_blocks"] = negative
    if negative:
        independent["is_feasible"] = False
        metrics["is_feasible"] = False
        metrics["cost"] = official.M_PENALTY
    return {"metrics": metrics, "independent_hard_checks": independent, "positions": positions}


def summarize_variants(cases, strategies):
    """Failures count as infeasible with cost 10; undefined gaps remain explicit."""
    official = official_evaluator()
    summaries = {}
    for strategy in strategies:
        records = [case["variants"][strategy] for case in cases]
        metrics = [record["metrics"] for record in records]
        returned = [metric for metric in metrics if metric.get("hpwl_gap") is not None]
        def mean(key):
            return sum(metric[key] for metric in returned) / len(returned) if returned else None
        summaries[strategy] = {
            "case_count": len(cases), "feasible_count": sum(metric["is_feasible"] for metric in metrics),
            "feasible_rate": sum(metric["is_feasible"] for metric in metrics) / len(cases),
            "execution_error_count": sum("error" in record for record in records),
            "neutral_runtime_mean_cost_all_cases": sum(metric["cost"] for metric in metrics) / len(cases),
            "neutral_runtime_weighted_cost_all_cases": official.compute_total_score(
                [metric["cost"] for metric in metrics], [case["input_summary"]["block_count"] for case in cases]),
            "mean_hpwl_gap_returned_geometry": mean("hpwl_gap"),
            "mean_area_gap_returned_geometry": mean("area_gap"),
            "mean_boundary_violations_returned_geometry": mean("boundary_violations"),
            "mean_grouping_violations_returned_geometry": mean("grouping_violations"),
            "mean_mib_violations_returned_geometry": mean("mib_violations"),
            "returned_geometry_metric_count": len(returned),
            "total_solve_seconds": sum(record.get("solve_seconds", 0) for record in records),
            "total_worker_wall_seconds": sum(record.get("worker_wall_seconds", 0) for record in records),
            "max_peak_worker_memory_bytes": max([record.get("worker_peak_memory_bytes") or 0 for record in records]) or None,
            "quality_scope": "all returned geometries, including infeasible ones; errors have undefined gaps and cost 10",
        }
    return summaries
