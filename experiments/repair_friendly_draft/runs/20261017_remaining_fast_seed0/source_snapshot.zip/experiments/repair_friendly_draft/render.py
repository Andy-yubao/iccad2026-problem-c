"""Render already-saved reference/draft/final coordinates; never reads datasets."""
import argparse
import html
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--run-dir',type=Path,required=True)
    args=p.parse_args();folder=args.run_dir.resolve();rows=[json.loads(s) for s in (folder/'cases.jsonl').read_text(encoding='utf-8').splitlines()]
    images=[]
    for i,row in enumerate(rows):
        for name,value in row['variants'].items():
            if 'error' in value:continue
            arrays=[np.asarray(row['reference_positions']),np.asarray(value['raw_positions']),np.asarray(value['final']['positions'])]
            hi=np.max(np.vstack([a[:,:2]+a[:,2:] for a in arrays]),axis=0)
            fig,axes=plt.subplots(1,3,figsize=(13,5),layout='constrained')
            titles=['Reference',f"Draft: void {value['raw_diagnostics']['empty_fraction']:.1%}",f"Final: Q {value['final']['metrics']['cost']:.4f}, repair {value['postprocess_seconds']:.3f}s"]
            for ax,positions,title in zip(axes,arrays,titles):
                for j,(x,y,w,h) in enumerate(positions):
                    group=int(row['constraints'][j][3]);color=plt.get_cmap('tab20')(group%20) if group else (.8,.8,.8,1)
                    ax.add_patch(Rectangle((x,y),w,h,facecolor=color,edgecolor='.35',alpha=.65,linewidth=.6))
                    ax.text(x+w/2,y+h/2,str(j),ha='center',va='center',fontsize=5)
                ax.set(xlim=(0,hi[0]*1.03),ylim=(0,hi[1]*1.03),title=title);ax.set_aspect('equal')
            fig.suptitle(row['case_id']+' / '+name,fontsize=10)
            filename=f'{i:03d}_{name}.png';fig.savefig(folder/filename,dpi=140);plt.close(fig)
            images.append(f'<h3>{html.escape(row["case_id"]+" / "+name)}</h3><img loading="lazy" src="{filename}" style="max-width:100%">')
    (folder/'index.html').write_text('<!doctype html><meta charset="utf-8"><title>E7 layouts</title>'+''.join(images),encoding='utf-8')
    print(json.dumps({'case_count':len(rows),'figures':len(images),'index':str(folder/'index.html')}))


if __name__=='__main__':main()
