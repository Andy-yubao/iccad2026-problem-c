"""Five fixed dev-quality cases: frozen proposal, old vs new public-input repair."""
import argparse,json,time,zipfile
from pathlib import Path
from datetime import datetime,timezone
import numpy as np
import torch
from datasets.paths import ROOT
from datasets.worksets import workset_manifest,LayoutReader
from datasets.cases import _build_case
from scoring.evaluation import evaluate_case
from scoring.official import official_evaluator
from .global_refine import refine
from .train import save,sha


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--seconds',type=float,default=15.)
    args=parser.parse_args();out=args.output.resolve();out.mkdir(parents=True,exist_ok=False)
    begin=time.monotonic();manifest=workset_manifest();reader=LayoutReader(manifest,'dev_quality')
    source=ROOT/'experiments/intent_aware_repair/runs/20261017_geometry_only_factorial_seed0/evaluation/cases.jsonl'
    existing=[json.loads(s) for s in source.read_text(encoding='utf-8').splitlines()]
    workers=[0,24,49,74,99]
    selected=[r for r in existing if int(r['source']['shard'].split('/')[0][7:]) in workers]
    assert len(selected)==5
    files=[*Path(__file__).parent.glob('*.py'),*sorted((ROOT/'scoring').glob('*.py')),*sorted((ROOT/'datasets').glob('*.py'))]
    config={'created_utc':datetime.now(timezone.utc).isoformat(),'case_ids':[r['case_id'] for r in selected],
        'source':str(source),'source_sha256':sha(source),'variant':'attention_geometry','seconds_per_case':args.seconds,
        'test_reads':0,'selection':'dev_quality workers0,24,49,74,99 fixed before current repair development',
        'source_sha256':{p.relative_to(ROOT).as_posix():sha(p) for p in files}}
    save(out/'config.json',config)
    with zipfile.ZipFile(out/'source_snapshot.zip','w',zipfile.ZIP_DEFLATED) as z:
        for p in files:z.write(p,p.relative_to(ROOT))
    records=[]
    with (out/'cases.jsonl').open('x',encoding='utf-8') as f:
        for row in selected:
            src=row['source'];idx=reader.members.index((src['shard'],src['sample_index']));case=reader.case(idx)
            old=row['variants']['attention_geometry'];raw=np.asarray(old['raw']['positions'])
            result,stats=refine(raw,case.solver_inputs,seconds=args.seconds)
            scoring=_build_case(case.case_id,case.source,case.solver_inputs[1:6],case.reference_positions,case.stored_metrics)
            evaluated=evaluate_case(scoring,result,stats['seconds'])
            item={'case_id':case.case_id,'block_count':case.block_count,'old':old['final']['metrics'],
                'new':evaluated,'trace':stats,'raw_source':str(source)}
            f.write(json.dumps(item,allow_nan=False)+'\n');f.flush();records.append(item)
            print(json.dumps({'case':case.case_id,'old_Q':item['old']['cost'],'new_Q':item['new']['metrics']['cost'],
                'BGM':[item['new']['metrics'][k] for k in ['boundary_violations','grouping_violations','mib_violations']],
                'seconds':stats['seconds'],'legal_candidates':sum(r['legal'] for r in stats['trace'])}),flush=True)
    official=official_evaluator();ids=[r['block_count'] for r in records]
    save(out/'results.json',{'status':'completed','cases':5,'test_reads':0,'wall_seconds':time.monotonic()-begin,
        'old_Q':official.compute_total_score([r['old']['cost'] for r in records],ids),
        'new_Q':official.compute_total_score([r['new']['metrics']['cost'] for r in records],ids),
        'new_feasible':sum(r['new']['metrics']['is_feasible'] for r in records),
        'scope':'five developer cases only, not fixed100 quality or generalization claim'})


if __name__=='__main__':main()
