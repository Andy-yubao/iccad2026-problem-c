"""At most five unique train/dev cases; functional checks, not training evidence."""
import argparse
import copy
from pathlib import Path
import tempfile
import numpy as np
import torch
from datasets.quality_layouts import QualityLayouts
from scoring.evaluation import evaluate_case
from .data import load_rows, collate
from .model import GeometryModel, decode
from .loss import losses, quality_terms, weights
from .io import HERE, save, checkpoint as write_checkpoint, sha
from .train import ARMS, run, seed_all, rng_state, restore_rng


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--output', type=Path, required=True)
    ap.add_argument('--device', default='cuda')
    args = ap.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    train, dev = load_rows('train', range(3)), load_rows('dev_monitor500', range(2))
    rows = train + dev
    graph, targets = collate(rows, args.device)
    result = {'scope': 'five unique cases; no convergence/quality claim', 'device': args.device,
              'unique_members': [list(r['member']) for r in rows], 'arms': {}, 'test_read': False, 'tail_test_read': False}
    for role in ('test', 'tail_test'):
        try:
            QualityLayouts(role)
        except PermissionError:
            result[role + '_denied'] = True
        else:
            raise AssertionError('Sealed role was opened')
    for arm in ARMS:
        seed_all(0)
        model = GeometryModel(192 if arm == 'curriculum_large' else 96, 4).to(args.device)
        initial = {k: v.detach().clone() for k, v in model.state_dict().items()}
        optimizer = torch.optim.AdamW(model.parameters(), lr=1e-4, weight_decay=1e-4)
        out = model(graph)
        values = losses(out, graph, targets, arm, 20)
        values['total'].backward()
        assert all(torch.isfinite(p.grad).all() for p in model.parameters() if p.grad is not None)
        norm = float(torch.nn.utils.clip_grad_norm_(model.parameters(), 1., error_if_nonfinite=True))
        optimizer.step()
        assert any(not torch.equal(v, initial[k]) for k, v in model.state_dict().items())
        # Compare an uninterrupted next update to a saved/restored update,
        # including optimizer state. The temporary checkpoint is not a result.
        saved_rng = rng_state()
        saved_model, saved_opt = copy.deepcopy(model.state_dict()), copy.deepcopy(optimizer.state_dict())
        optimizer.zero_grad(set_to_none=True)
        losses(model(graph), graph, targets, arm, 20)['total'].backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1., error_if_nonfinite=True)
        optimizer.step()
        expected = copy.deepcopy(model.state_dict())
        with tempfile.TemporaryDirectory(dir=args.output) as directory:
            path = Path(directory)/'resume.pt'
            write_checkpoint(path, {'model': saved_model, 'optimizer': saved_opt, 'rng': saved_rng})
            state = torch.load(path, map_location='cpu', weights_only=False)
            restored = GeometryModel(192 if arm == 'curriculum_large' else 96, 4).to(args.device)
            restored.load_state_dict(state['model'])
            opt = torch.optim.AdamW(restored.parameters(), lr=1e-4, weight_decay=1e-4)
            opt.load_state_dict(state['optimizer'])
            restore_rng(state['rng'])
            opt.zero_grad(set_to_none=True)
            losses(restored(graph), graph, targets, arm, 20)['total'].backward()
            torch.nn.utils.clip_grad_norm_(restored.parameters(), 1., error_if_nonfinite=True)
            opt.step()
            assert all(torch.equal(expected[k], v) for k, v in restored.state_dict().items())
        # Target coordinates are separate: editing supervision cannot alter
        # inference. Public rigid/preplaced specs are preserved by decoding.
        with torch.no_grad():
            prediction = decode(model(graph), graph)
            for i, row in enumerate(rows):
                c = graph['constraints'][i, :len(row['target']['geometry'])]
                locked, pre = c[:, :2].bool().any(-1), c[:, 1].bool()
                assert torch.equal(prediction[i, :len(c), 2:][locked], graph['specs'][i, :len(c), 2:][locked])
                assert torch.equal(prediction[i, :len(c)][pre], graph['specs'][i, :len(c)][pre])
        result['arms'][arm] = {'parameters': sum(p.numel() for p in model.parameters()),
            'losses': {k: float(v.detach()) for k, v in values.items()}, 'gradient_norm': norm,
            'finite_backward': True, 'parameter_identical_resume': True, 'hard_specs_preserved': True}
    # Exact wire/bbox components are checked against the unchanged evaluator,
    # using the same five labels; proxy soft terms are not called exact scores.
    for i, row in enumerate(rows):
        geometry = torch.zeros_like(graph['known'])
        for j, target in enumerate(targets):
            geometry[j, :len(target['geometry'])] = target['geometry']
        positions = decode(geometry, graph)
        components = quality_terms(positions, graph, targets)
        p = (positions[i, :len(targets[i]['geometry'])] * graph['scale'][i]).cpu().double().numpy()
        c, specs = np.asarray(row['case'].solver_inputs[5]), np.asarray(row['case'].solver_inputs[6])
        p[c[:, :2].any(1), 2:] = specs[c[:, :2].any(1), 2:]
        p[c[:, 1] != 0] = specs[c[:, 1] != 0]
        metrics = evaluate_case(row['case'], p.tolist(), 0)['metrics']
        np.testing.assert_allclose(float(components['wire_ratio'][i]), metrics['hpwl_total']/metrics['hpwl_baseline'], rtol=2e-5, atol=1e-6)
        np.testing.assert_allclose(float(components['bbox_ratio'][i]), metrics['bbox_area']/metrics['bbox_area_baseline'], rtol=2e-5, atol=1e-6)
    result['wire_bbox_matches_official'] = True
    # The quality objective is independent of the label coordinates.
    seed_all(0)
    probe = GeometryModel(96, 4).to(args.device)
    prediction = probe(graph)
    changed = copy.deepcopy(targets)
    for target in changed:
        target['geometry'] += 10
    before, after = [losses(prediction, graph, t, 'curriculum_small', 20) for t in (targets, changed)]
    assert torch.equal(before['quality_proxy'], after['quality_proxy'])
    assert not torch.equal(before['supervision'], after['supervision'])
    result['quality_independent_of_target_coordinates'] = True
    # A two-block counterexample checks that grouping rewards connectivity and
    # the legal penalty defeats the apparent wire/bbox gain from overlap.
    device = args.device
    synthetic_graph = {'constraints': torch.tensor([[[0,0,1,1,1],[0,0,1,1,2]]], device=device)}
    synthetic_target = [{'geometry': torch.zeros((2,3), device=device), 'wire_anchor': 1., 'area_anchor': 2.,
        'b2b': torch.tensor([[0.,1.,1.]], device=device), 'p2b': torch.empty((0,3), device=device),
        'pins': torch.empty((0,2), device=device), 'groups': [torch.arange(2, device=device)],
        'mibs': [torch.arange(2, device=device)]}]
    legal = torch.tensor([[[0.,0.,1.,1.],[1.,0.,1.,1.]]], device=device)
    overlap = legal.clone(); overlap[0,1,0] = .5
    separated = legal.clone(); separated[0,1,0] = 3.
    terms = [quality_terms(p, synthetic_graph, synthetic_target) for p in (legal, overlap, separated)]
    assert terms[0]['overlap'].item() == 0 and terms[1]['overlap'].item() > 0
    assert terms[0]['grouping'].item() == 0 and terms[2]['grouping'].item() > 0
    objective = lambda t: .5*(t['wire_ratio']+t['bbox_ratio'])+2*(t['boundary']+t['grouping']+t['mib'])+10*t['overlap']
    assert objective(terms[0]).item() < objective(terms[1]).item()
    result['connectivity_and_overlap_counterexample_passed'] = True
    assert weights('curriculum_small', 1) == {'supervision': 1., 'quality': .05, 'overlap': 10.}
    assert abs(weights('curriculum_small', 20)['supervision'] - .05) < 1e-12
    # Exercise the actual controller: interruption at one batch, then finish
    # that same epoch with a pending real repair/score monitor on two dev cases.
    config = argparse.Namespace(arm='curriculum_small', output=args.output/'controller', device=args.device,
        seed=0, max_hours=.12, max_epochs=1, batch_size=2, resume=False)
    run(config, implementation_check=True, stop_after_steps=1)
    first = torch.load(config.output/'checkpoints/latest.pt', map_location='cpu', weights_only=False)
    assert first['status'] == 'user_stop' and first['progress']['cursor'] == 2
    config.resume = True
    run(config, implementation_check=True)
    last = torch.load(config.output/'checkpoints/latest.pt', map_location='cpu', weights_only=False)
    assert last['finished'] and last['progress']['step'] == 2 and last['progress']['epoch'] == 1
    assert (config.output/'checkpoints/best.pt').exists()
    result['controller'] = {'interrupted_cursor': 2, 'resumed_steps': 2,
        'finished': last['finished'], 'quality': last['progress']['history'][-1]['quality']}
    result['passed'] = True
    save(args.output/'results.json', result)
    print('Five-case functional checks passed:', args.output, flush=True)


if __name__ == '__main__':
    main()
