"""Three scratch controls. Long training is launched by the user only."""
import argparse
import copy
import json
import os
from pathlib import Path
import random
import signal
import subprocess
import sys
import time
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
os.environ.setdefault('OMP_NUM_THREADS', '2')
os.environ.setdefault('OPENBLAS_NUM_THREADS', '2')
os.environ.setdefault('MKL_NUM_THREADS', '2')
import numpy as np
import torch
from datasets.quality_layouts import QualityLayouts, REGISTRY
from datasets.paths import resolved_data_paths
from .data import load_rows, collate
from .evaluation import quality_monitor
from .io import ROOT, HERE, sha, save, checkpoint as write_checkpoint, sources, snapshot
from .loss import losses, weights
from .model import GeometryModel

ARMS = ('supervised_small', 'curriculum_small', 'curriculum_large')


def seed_all(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.set_num_threads(2)
    torch.use_deterministic_algorithms(True)


def rng_state():
    return {'python': random.getstate(), 'numpy': np.random.get_state(), 'torch': torch.get_rng_state(),
            'cuda': torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None}


def restore_rng(state):
    random.setstate(state['python'])
    np.random.set_state(state['numpy'])
    torch.set_rng_state(state['torch'])
    if state['cuda'] is not None:
        torch.cuda.set_rng_state_all(state['cuda'])


@torch.no_grad()
def monitor_losses(model, rows, device, arm, epoch, batch_size):
    model.eval()
    sums = {}
    for start in range(0, len(rows), batch_size):
        selected = rows[start:start+batch_size]
        graph, targets = collate(selected, device)
        values = losses(model(graph), graph, targets, arm, epoch)
        for key, value in values.items():
            sums[key] = sums.get(key, 0.) + float(value) * len(selected)
    result = {key: value / len(rows) for key, value in sums.items()}
    result['count'] = len(rows)
    return result


def gradient_norm(value, parameters):
    grads = torch.autograd.grad(value, parameters, retain_graph=True, allow_unused=True)
    return float(sum(g.square().sum() for g in grads if g is not None).sqrt())


def parser():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--arm', choices=ARMS, required=True)
    ap.add_argument('--output', type=Path, required=True)
    ap.add_argument('--device', default='cuda')
    ap.add_argument('--seed', type=int, default=0)
    ap.add_argument('--max-hours', type=float, default=4.)
    ap.add_argument('--max-epochs', type=int, default=200)
    ap.add_argument('--batch-size', type=int, default=16)
    ap.add_argument('--resume', action='store_true')
    return ap


def run(args, *, implementation_check=False, stop_after_steps=None):
    begin = time.perf_counter()
    args.output = args.output.resolve()
    if not args.output.is_relative_to(HERE / 'runs'):
        raise ValueError('Training outputs must stay in E15/runs')
    if min(args.max_hours, args.max_epochs, args.batch_size) <= 0:
        raise ValueError('Positive budgets required')
    if args.device.startswith('cuda') and not torch.cuda.is_available():
        raise RuntimeError('CUDA unavailable: select --device cpu explicitly')
    seed_all(args.seed)
    source_identity = sources()
    width = 192 if args.arm == 'curriculum_large' else 96
    model = GeometryModel(width, 4).to(args.device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=1e-4, weight_decay=1e-4)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, factor=.5, patience=3,
                        threshold=1e-5, threshold_mode='abs', min_lr=1e-6)
    train_meta, dev_meta = QualityLayouts('train'), QualityLayouts('dev')
    train_mon_meta, dev_mon_meta = QualityLayouts('train_monitor500'), QualityLayouts('dev_monitor500')
    train_members = {tuple(r['member']): i for i, r in enumerate(train_meta.records)}
    dev_members = {tuple(r['member']) for r in dev_meta.records}
    if set(train_members) & dev_members or {m[0] for m in train_members} & {m[0] for m in dev_members}:
        raise ValueError('Student train/dev overlap')
    train_monitor_ids = [train_members[tuple(r['member'])] for r in train_mon_meta.records]
    if not all(tuple(r['member']) in dev_members for r in dev_mon_meta.records):
        raise ValueError('Dev monitor not nested')
    qids = list(range(len(dev_mon_meta.records)))
    identity = {'arm': args.arm, 'initialization': 'random; no pretrained weights', 'width': width, 'layers': 4,
                'parameters': sum(p.numel() for p in model.parameters()), 'sources': source_identity,
                'registry_sha256': sha(REGISTRY), 'paths_sha256': sha(ROOT/'protocol/paths.json'),
                'seed': args.seed, 'device': args.device, 'torch': str(torch.__version__),
                'cuda': torch.version.cuda, 'numpy': np.__version__,
                'device_name': torch.cuda.get_device_name(args.device) if args.device.startswith('cuda') else 'cpu',
                'max_seconds': args.max_hours*3600, 'max_epochs': args.max_epochs, 'batch_size': args.batch_size,
                'lr': 1e-4, 'weight_decay': 1e-4, 'clip_norm': 1.,
                'quality_monitor_epochs': '5, then every10, plus max_epochs',
                'schedule': 'epochs1..5: sup1 quality.05 overlap10; linear epochs6..20 to sup.05 quality1 overlap10; supervised arm sup1 only',
                'selection': 'lexicographic (infeasible count, module-count weighted real postprocessed Q), min_delta=1e-5',
                'lr_patience_quality_checks': 4, 'early_patience_quality_checks': 12,
                'scheduler_start_epoch': 20, 'quality_panel_members': [dev_mon_meta.records[i]['member'] for i in qids],
                'postprocess': {'normal_total_target': 5., 'normal_fast_target': 1.3, 'extra_rescue_target': 16.},
                'implementation_check': implementation_check, 'test_read': False, 'tail_test_read': False}
    prior = 0.
    previous = None
    if args.resume:
        previous = torch.load(args.output/'checkpoints/latest.pt', map_location='cpu', weights_only=False)
        if previous['identity'] != identity:
            raise ValueError('Resume code/data/parameters/device/budget identity mismatch')
        if previous['finished']:
            print(f'{args.arm}: already finished ({previous["status"]})', flush=True)
            return
        if (args.output/'STOP').exists():
            raise ValueError('Remove the STOP file before resuming')
        model.load_state_dict(previous['model'])
        optimizer.load_state_dict(previous['optimizer'])
        scheduler.load_state_dict(previous['scheduler'])
        prior = previous['elapsed_seconds']
        ledger_path = args.output/'budget.json'
        if ledger_path.exists():
            prior = max(prior, json.loads(ledger_path.read_text(encoding='utf-8'))['elapsed_seconds'])
    else:
        args.output.mkdir(parents=True, exist_ok=False)
        save(args.output/'config.json', {'identity': identity, 'command': [sys.executable, *sys.argv],
            'commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
            'git_status': subprocess.check_output(['git', 'status', '--short'], cwd=ROOT, text=True).strip(),
            'data_paths': resolved_data_paths(), 'device': args.device,
            'timing': 'Cumulative wall budget includes data preparation, validation, postprocessing and checkpoints. Slow solver calls may overshoot the target.'})
        snapshot(args.output/'source_snapshot.zip', identity)
        write_checkpoint(args.output/'checkpoints/latest.pt', {
            'model': model.state_dict(), 'model_config': {'width': width, 'layers': 4},
            'optimizer': optimizer.state_dict(), 'scheduler': scheduler.state_dict(),
            'rng': rng_state(), 'progress': None, 'identity': identity,
            'elapsed_seconds': time.perf_counter()-begin, 'status': 'loading', 'finished': False})
    calls_path = args.output/'invocations.json'
    calls = json.loads(calls_path.read_text(encoding='utf-8')) if calls_path.exists() else []
    calls.append({'argv': [sys.executable, *sys.argv], 'resume': args.resume, 'prior_seconds': prior,
                  'started_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())})
    save(calls_path, calls)
    elapsed = lambda: prior + time.perf_counter() - begin
    def heartbeat():
        save(args.output/'budget.json', {'elapsed_seconds': elapsed()})
    heartbeat()
    if prior >= identity['max_seconds']:
        previous.update(status='budget', finished=True, elapsed_seconds=prior)
        write_checkpoint(args.output/'checkpoints/latest.pt', previous)
        save(args.output/'progress.json', {'status': 'budget', 'finished': True,
             'elapsed_seconds': prior, 'test_read': False, 'tail_test_read': False,
             'note': 'Cumulative wall budget exhausted before preparation reload'})
        print('Cumulative wall budget already exhausted; no data reload or training', flush=True)
        return
    print(f'{args.arm}: {identity["parameters"]:,} parameters, random initialization; loading frozen train/dev', flush=True)
    if implementation_check:
        train = load_rows('train', range(3))
        dev = load_rows('dev_monitor500', range(2))
        train_monitor_ids = list(range(3))
        qids = [0, 1]
    else:
        train = load_rows('train', on_progress=heartbeat)
        dev = load_rows('dev_monitor500', on_progress=heartbeat)
    qrows = [dev[i] for i in qids]
    train_monitor = [train[i] for i in train_monitor_ids]
    save(args.output/'panels.json', {'train_count': len(train), 'dev_monitor_count': len(dev),
         'train_monitor_members': [list(r['member']) for r in train_monitor],
         'quality_members': [list(r['member']) for r in qrows], 'implementation_check': implementation_check,
         'test_read': False, 'tail_test_read': False})
    progress = {'epoch': 0, 'cursor': 0, 'order': None, 'step': 0, 'seen': np.zeros(len(train), dtype=bool),
                'best_rank': None, 'best_epoch': None, 'bad_checks': 0, 'pending_monitor': False,
                'history': [], 'gradient_history': [], 'batch_history': [], 'full_dev_complete': False}
    if previous and previous['progress'] is not None:
        progress = previous['progress']
        restore_rng(previous['rng'])
    requested = [False]
    old_signal = signal.signal(signal.SIGINT, lambda *_: requested.__setitem__(0, True))
    def stopped():
        return requested[0] or (args.output/'STOP').exists() or (stop_after_steps is not None and progress['step'] >= stop_after_steps)
    def exhausted():
        return elapsed() >= identity['max_seconds']
    def store(status, finished=False, best=False):
        heartbeat()
        state = {'model': model.state_dict(), 'model_config': {'width': width, 'layers': 4},
                 'optimizer': optimizer.state_dict(), 'scheduler': scheduler.state_dict(), 'rng': rng_state(),
                 'progress': progress, 'identity': identity, 'elapsed_seconds': elapsed(),
                 'status': status, 'finished': finished}
        write_checkpoint(args.output/'checkpoints/latest.pt', state)
        if best:
            write_checkpoint(args.output/'checkpoints/best.pt', state)
        save(args.output/'progress.json', {'status': status, 'finished': finished,
            'epoch': progress['epoch'], 'cursor': progress['cursor'], 'step': progress['step'],
            'seen_count': int(progress['seen'].sum()), 'elapsed_seconds': elapsed(),
            'best_rank': progress['best_rank'], 'best_epoch': progress['best_epoch'],
            'bad_quality_checks': progress['bad_checks'], 'history': progress['history'],
            'gradients': progress['gradient_history'], 'batch_history': progress['batch_history'],
            'full_dev_complete': progress['full_dev_complete'],
            'test_read': False, 'tail_test_read': False, 'implementation_check': implementation_check})
    def monitor():
        epoch = progress['epoch']
        if stopped() or exhausted():
            return False
        dev_values = monitor_losses(model, dev, args.device, args.arm, max(1, epoch), args.batch_size)
        train_values = monitor_losses(model, train_monitor, args.device, args.arm, max(1, epoch), args.batch_size)
        seen = progress['seen'][train_monitor_ids]
        record = {'epoch': epoch, 'step': progress['step'], 'dev_monitor': dev_values,
                  'train_monitor': train_values, 'train_seen_count': int(seen.sum()),
                  'weights': weights(args.arm, max(1, epoch)), 'lr': optimizer.param_groups[0]['lr']}
        if seen.any():
            record['train_seen'] = train_values if seen.all() else monitor_losses(model,
                [r for r, flag in zip(train_monitor, seen) if flag], args.device, args.arm, max(1, epoch), args.batch_size)
        if (~seen).any():
            record['train_unseen'] = train_values if not seen.any() else monitor_losses(model,
                [r for r, flag in zip(train_monitor, seen) if not flag], args.device, args.arm, max(1, epoch), args.batch_size)
        improved = False
        if epoch and (epoch == 5 or epoch % 10 == 0 or epoch == args.max_epochs or implementation_check):
            print(f'epoch={epoch}: evaluating real postprocessed Q on {len(qrows)} fixed dev cases', flush=True)
            final_path = args.output/f'quality/epoch_{epoch:04d}.json'
            partial_path = args.output/f'quality/epoch_{epoch:04d}.partial.json'
            def quality_progress(records, stopping):
                heartbeat()
                if stopping or len(records) % 10 == 0:
                    save(partial_path, records)
            if final_path.exists():
                quality = json.loads(final_path.read_text(encoding='utf-8'))
                if [tuple(r['member']) for r in quality['records']] != [r['member'] for r in qrows]:
                    raise ValueError('Cached quality panel mismatch')
            else:
                existing = json.loads(partial_path.read_text(encoding='utf-8')) if partial_path.exists() else None
                quality = quality_monitor(model, qrows, args.device, should_stop=lambda: stopped() or exhausted(),
                                          existing=existing, on_record=quality_progress)
            if quality is None:
                return False
            save(final_path, quality)
            if partial_path.exists():
                partial_path.unlink()
            record['quality'] = quality['summary']
            rank = [len(qrows)-quality['summary']['hard_legal'], quality['summary']['weighted_Q']]
            best = progress['best_rank']
            improved = best is None or rank[0] < best[0] or (rank[0] == best[0] and rank[1] < best[1]-1e-5)
            if improved:
                progress['best_rank'], progress['best_epoch'], progress['bad_checks'] = rank, epoch, 0
            elif epoch >= 20:
                progress['bad_checks'] += 1
            if epoch >= 20:
                scheduler.step(quality['summary']['weighted_Q'] + 10*rank[0]/len(qrows))
            print(f'Q={quality["summary"]["mean_Q"]:.6f}, weighted_Q={rank[1]:.6f}, hard_legal={quality["summary"]["hard_legal"]}/{len(qrows)}', flush=True)
        record['elapsed_seconds'] = elapsed()
        progress['history'].append(record)
        progress['pending_monitor'] = False
        store('running', best=improved)
        print(f'epoch={epoch}, step={progress["step"]}, dev_supervision={dev_values["supervision"]:.6f}, dev_quality_proxy={dev_values["quality_proxy"]:.6f}, lr={optimizer.param_groups[0]["lr"]:.2g}', flush=True)
        return True
    status = 'running'
    try:
        if previous is None or previous['progress'] is None:
            store('prepared')
            # Initial fixed losses are diagnostics; random drafts do not trigger
            # an expensive 500-case numerical repair pass.
            monitor()
        while progress['epoch'] < args.max_epochs or progress['pending_monitor']:
            if stopped() or exhausted():
                status = 'user_stop' if stopped() else 'budget'
                break
            if progress['pending_monitor']:
                if not monitor():
                    status = 'user_stop' if stopped() else 'budget'
                    break
                if progress['bad_checks'] >= 12:
                    status = 'early_stop'
                    break
                continue
            if progress['order'] is None:
                progress['order'] = np.random.default_rng(args.seed+progress['epoch']).permutation(len(train))
                progress['cursor'] = 0
            model.train()
            while progress['cursor'] < len(train):
                if stopped() or exhausted():
                    break
                ids = progress['order'][progress['cursor']:progress['cursor']+args.batch_size]
                graph, targets = collate([train[i] for i in ids], args.device)
                optimizer.zero_grad(set_to_none=True)
                values = losses(model(graph), graph, targets, args.arm, progress['epoch']+1)
                if not all(torch.isfinite(value) for value in values.values()):
                    raise RuntimeError('Nonfinite training loss component')
                if progress['cursor'] == 0:
                    params = list(model.parameters())
                    w = weights(args.arm, progress['epoch']+1)
                    progress['gradient_history'].append({'epoch': progress['epoch']+1, 'weights': w,
                        'supervision_grad_norm': gradient_norm(values['supervision'], params),
                        'quality_grad_norm': gradient_norm(values['quality_proxy'], params),
                        'overlap_grad_norm': gradient_norm(values['overlap'], params)})
                values['total'].backward()
                norm = float(torch.nn.utils.clip_grad_norm_(model.parameters(), 1., error_if_nonfinite=True))
                optimizer.step()
                progress['seen'][ids] = True
                progress['cursor'] += len(ids)
                progress['step'] += 1
                heartbeat()
                if progress['step'] % 100 == 0:
                    progress['batch_history'].append({'step': progress['step'], 'epoch': progress['epoch']+1,
                       'losses': {k: float(v.detach()) for k, v in values.items()}, 'grad_norm': norm,
                       'elapsed_seconds': elapsed()})
                    store('running')
                    print(f'step={progress["step"]}, epoch={progress["epoch"]+1}, samples={progress["cursor"]}/{len(train)}, total={float(values["total"]):.5f}', flush=True)
            if progress['cursor'] < len(train):
                status = 'user_stop' if stopped() else 'budget'
                break
            progress['epoch'] += 1
            progress['order'], progress['cursor'], progress['pending_monitor'] = None, 0, True
            store('monitor_pending')
        if status == 'running':
            status = 'max_epochs'
        # Resume-safe terminal assessment on full dev2000. This does not load
        # student tests and does not replace the real repaired-Q selection.
        if status in ('max_epochs', 'early_stop') and not implementation_check and not exhausted() and not stopped():
            best_path = args.output/'checkpoints/best.pt'
            if best_path.exists():
                current = copy.deepcopy(model.state_dict())
                best_state = torch.load(best_path, map_location='cpu', weights_only=False)
                try:
                    model.load_state_dict(best_state['model'])
                    full_dev = load_rows('dev', on_progress=heartbeat)
                    values = monitor_losses(model, full_dev, args.device, args.arm, best_state['progress']['epoch'], args.batch_size)
                    save(args.output/'full_dev.json', {'checkpoint_sha256': sha(best_path),
                        'count': len(full_dev), 'losses': values, 'scope': 'best checkpoint geometry/proxy diagnostics; not repaired Q', 'test_read': False})
                    progress['full_dev_complete'] = True
                finally:
                    model.load_state_dict(current)
        store(status, finished=status in ('budget', 'max_epochs', 'early_stop'))
        save(args.output/'results.json', {'status': status, 'elapsed_seconds': elapsed(), 'steps': progress['step'],
            'epochs': progress['epoch'], 'best_epoch': progress['best_epoch'], 'best_rank': progress['best_rank'],
            'full_dev_complete': progress['full_dev_complete'], 'full_dev_pending': not progress['full_dev_complete'],
            'implementation_check': implementation_check, 'test_read': False, 'tail_test_read': False,
            'curriculum_completed': args.arm == 'supervised_small' or progress['epoch'] >= 20,
            'quality_scope': 'MIB-derived task, neutral runtime Q with original denominators; not a contest score'})
        print(f'Stopped: {status}; total wall {elapsed()/3600:.3f} h; best epoch {progress["best_epoch"]}', flush=True)
    except BaseException:
        store('error')
        raise
    finally:
        signal.signal(signal.SIGINT, old_signal)


if __name__ == '__main__':
    run(parser().parse_args())
