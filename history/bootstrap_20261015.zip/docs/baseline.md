# 官方基线首次运行记录

日期：2026-10-15。**未修改官方求解器或评测器，完成公开验证集的两个端点规模单例；不是 100 例完整评测。**

后续记录：独立 conda 环境中的 [100 例评测](../experiments/official_baseline/full100_clean_cu128_seed0/run/results.json)已完成；最新结论见[5 例对照核查](baseline_audit.md)。本文件保留首次两个单例的历史结果。

## 结论

官方 B*-tree + Simulated Annealing 模板能够在本地运行，数据加载正常，没有遇到 PyTorch 反序列化错误。两个单例均正常返回布局，但均因 fixed-shape / preplaced 硬约束违反而不可行，cost=10。这是已运行实例的结论，不能据此声称 100 个实例都会失败。

| 公开验证索引 | 模块数 | solve 耗时 | 重叠违反 | 面积违反 | 尺寸/预放置规格违反 | 可行 | 本地 cost |
|---:|---:|---:|---:|---:|---:|---|---:|
| 0 (`config_21`) | 21 | 2.756965 s | 0 | 0 | 2 块 | 否 | 10.0 |
| 99 (`config_120`) | 120 | 204.143443 s | 0 | 0 | 10 块 | 否 | 10.0 |

120 模块的具体原始耗时以 [results.json](../experiments/official_baseline/smoke_largest/results.json) 为准；此表由日志与结果文件整理。本地 cost 使用 `RuntimeFactor=1`，不是正式比赛的跨提交运行时间分数。由于最大单例已需约 3.4 分钟，本次未启动完整 100 例长跑。

## 环境与协议

- 只读复用已有 conda 环境 `D:\tools\anaconda3\envs\livetalking`，没有安装、卸载或升级其中的包，也没有修改 base。
- Python 3.10.19；torch 2.7.1+cu128；numpy 1.26.4；shapely 2.1.2；matplotlib 3.10.8；tqdm 4.65.2；requests 2.28.2。
- Windows 本地运行，CPU 执行官方 SA，PyTorch CPU 线程数为 1；GPU 可用但该算法不使用 GPU。
- 两个单例分别在新进程中运行，Python / NumPy / PyTorch 随机种子均设为 0。因此它们不等同于从同一个随机流顺序运行 100 例时对应两例的结果。
- 优化器参数保持原始默认值：initial_temp=100、final_temp=1、cooling_rate=0.9、moves_per_temp=20。未调参、未训练。
- 上游提交 `aadddcc2238695eb21e6542b8a6cd9e9fe6b80fa`；官方代码完整性仍由 `docs/upstream_manifest.json` 校验。
- [environment.yml](../environment.yml) 提供单独新建 `iccad2026` conda 环境的依赖声明；本次没有创建该环境，实际运行的解释器与包版本记录在各实验目录的 `environment.json`。

## 为什么会不可行

模板开头明确写明：保证无重叠和面积要求，但不处理 fixed、preplaced、MIB、cluster、boundary。实际 `solve()` 会从 `target_positions` 初始化固定块尺寸，却仍随机旋转这些块，且不锁定预放置块的位置；代价函数只包含 HPWL 和 `0.01 × bbox_area`。

21 模块实例中，有两块明确违反硬规格（模块编号从 0 开始）：

- fixed-shape 块 15：要求 `(w,h)=(18,26)`，输出变成 `(26,18)`。
- preplaced 块 17：要求 `(x,y,w,h)=(71,0,18,26)`，输出约为 `(33.906,61.267,26,18)`，位置和尺寸都改变。

120 模块实例有 10 块 fixed/preplaced 规格违反。详细计数与每块输入/输出对照见 `diagnostics.json`。两例均通过独立调用官方 `evaluate_solution()` 重评分，重新计算的可行性及 cost 与原运行结果一致；诊断重评分将 runtime/median 都置为 1，使其对应本地中性的 runtime 因子，真实 solve 耗时仍以 `results.json` 为准。

此外，两例的 HPWL 分别比参考值高约 144.53%、147.61%，包围盒面积高约 23.39%、52.98%；软约束相对违反为 0.695652、0.850746。由于硬约束已失败，这些指标不能使最终 cost 低于 10。

## 运行命令

在工作区根目录，使用已有 conda 环境运行；输出目录必须不存在，避免覆盖历史结果：

```powershell
conda activate livetalking
$env:PYTHONDONTWRITEBYTECODE = '1'
$env:PYTHONIOENCODING = 'utf-8'

python .\scripts\run_official_baseline.py --test-id 0 --seed 0 --output-dir experiments\official_baseline\rerun_21_seed0
python .\scripts\run_official_baseline.py --test-id 99 --seed 0 --output-dir experiments\official_baseline\rerun_120_seed0

# 对某次保存的结果生成硬约束诊断与布局图
python .\scripts\analyze_official_baseline.py experiments\official_baseline\rerun_21_seed0\results.json
```

无需激活环境时，也可以直接使用其完整解释器路径，或 `conda run --no-capture-output -n livetalking python ...`。本轮实际用完整解释器路径执行，具体参数在 `environment.json` 中。

如果后续建立独立研究环境，可以执行 `conda env create -f environment.yml`，然后 `conda activate iccad2026`。这份环境定义使用 CUDA 12.8 的 torch wheel；基线本身使用 CPU。

启动器调用原始官方 CLI，显式传入数据路径并将工作目录切至实验目录，只负责种子、线程数、日志和输出位置。**去掉 `--test-id` 会顺序评测全部 100 个实例，耗时尚未实测；不要误当成单例命令。**

## 结果与布局

| 实例 | 原始结果 | 日志 | 硬约束诊断 | 布局图 |
|---|---|---|---|---|
| 21 模块 | [results.json](../experiments/official_baseline/smoke_native/results.json) | [run.log](../experiments/official_baseline/smoke_native/run.log) | [diagnostics.json](../experiments/official_baseline/smoke_native/diagnostics.json) | [PNG](../experiments/official_baseline/smoke_native/layout_case_00.png) |
| 120 模块 | [results.json](../experiments/official_baseline/smoke_largest/results.json) | [run.log](../experiments/official_baseline/smoke_largest/run.log) | [diagnostics.json](../experiments/official_baseline/smoke_largest/diagnostics.json) | [PNG](../experiments/official_baseline/smoke_largest/layout_case_99.png) |

每个目录另有完整的 `optimizer_template_solutions.json`、环境信息和运行完成记录。参考布局只用于运行后的可视化、计分与诊断，没有额外传给求解器。

![21-block reference and baseline output](../experiments/official_baseline/smoke_native/layout_case_00.png)

![120-block reference and baseline output](../experiments/official_baseline/smoke_largest/layout_case_99.png)

这轮验证了“数据与官方接口能运行”，也确认该模板在这两例中不能满足当前硬约束。后续若修复约束处理，应作为独立适配基线保存，并与本次未修改的原版结果分开比较。
