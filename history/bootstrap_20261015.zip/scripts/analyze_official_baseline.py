"""Re-score saved official outputs with detailed hard-constraint diagnostics."""
import argparse
from dataclasses import asdict
import json
import os
from pathlib import Path
import sys


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('results', type=Path)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    os.environ['MPLBACKEND'] = 'Agg'
    os.environ['MPLCONFIGDIR'] = str(root / '.cache/matplotlib')
    contest = root / 'third_party/FloorSet/iccad2026contest'
    sys.path.insert(0, str(contest))
    import iccad2026_evaluate as official
    import matplotlib.pyplot as plt
    from matplotlib.patches import Rectangle
    evaluator = official.ContestEvaluator(str(contest.parent), verbose=False)
    evaluator._load_dataset()
    result = json.loads(args.results.read_text(encoding='utf-8'))
    diagnostics = []
    for entry in result['test_results']:
        if entry.get('error') or entry['positions'] is None:
            diagnostics.append({'test_id': entry['test_id'], 'error': entry.get('error')})
            continue
        idx = entry['test_id']
        sample = evaluator.dataset[idx]
        areas, b2b, p2b, pins, constraints = sample['input']
        baseline, target = evaluator._extract_baseline(idx, sample['label'], b2b, p2b, pins, entry['block_count'])
        metrics = official.evaluate_solution({'positions': entry['positions'], 'runtime': 1.0}, baseline,
                                            constraints, b2b, p2b, pins, areas, target, median_runtime=1.0)
        metrics_dict = asdict(metrics)
        assert metrics.is_feasible == entry['is_feasible']
        assert abs(metrics.cost - entry['cost']) < 1e-9
        bad_blocks = []
        for i, (position, spec) in enumerate(zip(entry['positions'], target)):
            fixed, preplaced = bool(constraints[i, 0]), bool(constraints[i, 1])
            if not (fixed or preplaced):
                continue
            dims_changed = any(abs(position[j] - spec[j]) > 1e-4 for j in [2, 3])
            pos_changed = preplaced and any(abs(position[j] - spec[j]) > 1e-4 for j in [0, 1])
            if dims_changed or pos_changed:
                bad_blocks.append({'block_id': i, 'fixed': fixed, 'preplaced': preplaced,
                                   'dimensions_changed': dims_changed, 'preplaced_position_changed': pos_changed,
                                   'output_xywh': position, 'specified_xywh': spec})
        diagnostics.append({'test_id': idx, 'block_count': entry['block_count'], 'metrics': metrics_dict,
                            'violating_fixed_or_preplaced_blocks': bad_blocks})
        fig, axes = plt.subplots(1, 2, figsize=(13, 6), layout='constrained')
        bad_ids = {x['block_id'] for x in bad_blocks}
        for ax, positions, title in zip(axes, [target, entry['positions']], ['Dataset reference (not optimizer input)', 'Official B*-tree SA output']):
            for i, (x, y, w, h) in enumerate(positions):
                is_pre = bool(constraints[i, 1])
                is_fix = bool(constraints[i, 0])
                color = '#f3b44c' if is_pre else '#8db7df' if is_fix else '#dce7df'
                ax.add_patch(Rectangle((x, y), w, h, facecolor=color,
                                       edgecolor='#d52e35' if i in bad_ids else '#555555', linewidth=1))
                if len(positions) <= 35:
                    ax.text(x + w / 2, y + h / 2, str(i), fontsize=7, ha='center', va='center')
            ax.autoscale_view()
            ax.margins(.04)
            ax.set_aspect('equal')
            ax.set_title(title)
            ax.set_xlabel('x')
            ax.set_ylabel('y')
        fig.suptitle(f"Case {idx}: {entry['block_count']} blocks | cost={entry['cost']:.2f} | dimension/location violations={metrics.dimension_violations}\nOrange=preplaced, blue=fixed-shape; red outlines=blocks violating hard specifications")
        fig.savefig(args.results.parent / f'layout_case_{idx:02}.png', dpi=150)
        plt.close(fig)
    output = args.results.parent / 'diagnostics.json'
    output.write_text(json.dumps(diagnostics, indent=2) + '\n', encoding='utf-8')
    print(json.dumps([{k: v for k, v in d.items() if k != 'violating_fixed_or_preplaced_blocks'} for d in diagnostics], indent=2))


if __name__ == '__main__':
    main()
