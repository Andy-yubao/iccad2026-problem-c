"""Background supervisor: clean conda prefix, pinned CUDA packages, 100 cases.

Run with the existing base Python; no packages are added to base. See status.json
and setup.log under --job-dir for phase/error details. No solver code is patched.
"""
import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess
import sys
import traceback


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--job-dir', type=Path, required=True)
    parser.add_argument('--prefix', type=Path, required=True)
    parser.add_argument('--conda', type=Path, required=True)
    parser.add_argument('--resume-setup', action='store_true', help='Resume setup of this job-created conda prefix after a failed installation')
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    job = args.job_dir.resolve()
    prefix = args.prefix.resolve()
    if not prefix.is_relative_to(root):
        raise ValueError('Conda prefix must be inside the workspace')
    job.mkdir(parents=True, exist_ok=True)
    state = {'supervisor_pid': os.getpid(), 'job_directory': str(job), 'conda_prefix': str(prefix),
             'seed': 0, 'cases_requested': 100, 'solver': 'unmodified official optimizer_template.py',
             'created_at_utc': datetime.now(timezone.utc).isoformat()}

    def update(phase, **extra):
        state.update(phase=phase, updated_at_utc=datetime.now(timezone.utc).isoformat(), **extra)
        temp = job / 'status.json.tmp'
        temp.write_text(json.dumps(state, indent=2) + '\n', encoding='utf-8')
        temp.replace(job / 'status.json')
        with (job / 'status-history.jsonl').open('a', encoding='utf-8') as history:
            history.write(json.dumps(state) + '\n')

    env = os.environ.copy()
    temp_root = root / '.cache/tmp/full100'
    temp_root.mkdir(parents=True, exist_ok=True)
    env.update(PYTHONDONTWRITEBYTECODE='1', PYTHONIOENCODING='utf-8', PYTHONUNBUFFERED='1',
               TEMP=str(temp_root), TMP=str(temp_root), TMPDIR=str(temp_root),
               CONDA_PKGS_DIRS=str(root / '.conda/pkgs'),
               CONDA_ENVS_PATH=str(root / '.conda/envs'),
               PIP_CACHE_DIR=str(root / '.cache/pip'),
               CONDA_OVERRIDE_CUDA='12.8',
               MPLCONFIGDIR=str(root / '.cache/matplotlib'), MPLBACKEND='Agg')

    def run(command, phase):
        update(phase, command=[str(x) for x in command])
        with (job / 'setup.log').open('a', encoding='utf-8') as log:
            log.write('\nCOMMAND: ' + subprocess.list2cmdline([str(x) for x in command]) + '\n')
            log.flush()
            proc = subprocess.Popen([str(x) for x in command], cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
            update(phase, child_pid=proc.pid)
            code = proc.wait()
            if code:
                raise RuntimeError(f'{phase} exited with code {code}; see setup.log')

    try:
        update('initializing')
        if prefix.exists():
            if not (args.resume_setup and (prefix / 'conda-meta/history').is_file() and (prefix / 'python.exe').is_file()):
                raise FileExistsError(f'Refusing to reuse an existing environment: {prefix}')
        else:
            run([args.conda, '--no-plugins', 'create', '--solver', 'classic', '--yes', '--prefix', prefix, '--override-channels', '--channel',
                 'conda-forge', 'python=3.10', 'pip'], 'creating_conda_environment')
        python = prefix / 'python.exe'
        run([python, '-m', 'pip', 'install', '--extra-index-url', 'https://download.pytorch.org/whl/cu128',
             'torch==2.7.1+cu128', 'numpy==1.26.4', 'shapely==2.1.2', 'matplotlib==3.10.8',
             'tqdm==4.65.2', 'requests==2.28.2'], 'installing_dependencies')
        check = (
            'import torch,numpy,shapely,matplotlib,tqdm,requests; '
            'assert torch.cuda.is_available(); '
            'a=torch.ones((64,64),device="cuda"); b=a@a; torch.cuda.synchronize(); '
            'assert b[0,0].item()==64.0; '
            'print(torch.__version__,torch.version.cuda,torch.cuda.get_device_name(0)); '
            'print("Fresh environment GPU compute check passed")'
        )
        run([python, '-c', check], 'validating_fresh_environment')
        run([args.conda, 'list', '--prefix', prefix, '--explicit'], 'recording_conda_packages')
        with (job / 'requirements-freeze.txt').open('w', encoding='utf-8') as log:
            subprocess.run([str(python), '-m', 'pip', 'freeze'], cwd=root, env=env, stdout=log, check=True)
        run([python, root / 'scripts/run_official_baseline.py', '--seed', '0', '--threads', '1',
             '--output-dir', job / 'run'], 'running_100_cases')
        results = json.loads((job / 'run/results.json').read_text(encoding='utf-8'))
        if len(results['test_results']) != 100:
            raise ValueError('Official evaluator did not return all 100 cases')
        update('completed', cases_completed=100, summary=results['summary'], total_score=results['total_score'])
    except BaseException as exc:
        (job / 'error.log').write_text(traceback.format_exc(), encoding='utf-8')
        update('failed', error=str(exc))
        raise


if __name__ == '__main__':
    main()
